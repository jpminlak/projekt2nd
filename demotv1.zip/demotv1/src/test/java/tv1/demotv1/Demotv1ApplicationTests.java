package tv1.demotv1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demotv1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
